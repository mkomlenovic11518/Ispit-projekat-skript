from django.db import models
#from django.contrib.auth.models import User

# Create your models here.
class Proizvodjac(models.Model):
    naziv_proizvodjac=models.CharField(max_length=64)
    sifra_proizvodjac = models.CharField(max_length=5)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)


    def __str__(self):
        return self.naziv_proizvodjac


class Roba(models.Model):
    naziv_robe=models.CharField(max_length=64)
    sifra_robe=models.CharField(max_length=5)
    kolicina=models.IntegerField(default=0)
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)
    proizvodjac=models.ForeignKey(Proizvodjac,on_delete=models.CASCADE)

class User(models.Model):
    ime=models.CharField(max_length=64)
    prezime=models.CharField(max_length=65)
    email = models.CharField(max_length=65)
    username = models.CharField(max_length=65)
    password = models.CharField(max_length=255)
    administrator = models.IntegerField(default=0)
    class Meta:
        db_table = "user"


