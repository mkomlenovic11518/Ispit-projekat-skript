const express=require('express');
const rtr=express.Router();
bodyParser = require('body-parser');
//rtr.use(bodyParser.urlencoded({ extended: false }));
rtr.use(bodyParser.json());

const config = require("../config/config");
const moment = require('moment')

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const joi=require('Joi');

mysql = require('mysql'); // import mysql module
const pool=mysql.createPool({
    connectionLimit:100,
    host: 'localhost',
    user: 'marko',
    password: 'komlen68',
    database: 'finproject'
});

// validacija za registraciju korisnika
const sema_user=joi.object({
    ime: joi.string().trim().min(4).max(45).required(),
    prezime: joi.string().trim().min(2).max(45).required(),
    email: joi.string().email().required(),
    username: joi.string().trim().min(4).max(10).alphanum().required(),
    password: joi.string().trim().min(4).required(),
    administrator:joi.number().integer().default(0)
  });

//validacija za proizvodjaca
const sema_producer=joi.object({
    naziv_proizvodjac: joi.string().trim().min(1).max(45).required(),
    sifra_proizvodjac: joi.string().trim().min(4).max(45).required(),
    created : joi.date().raw().required(),
    updated : joi.date().raw().required(),
});

const sema_roba=joi.object({
    naziv_robe: joi.string().trim().min(1).max(45).required(),
    sifra_robe: joi.string().trim().min(2).max(5).required(),
    created : joi.date().raw().required(),
    updated : joi.date().raw().required(),
    proizvodjac_id:joi.number().integer().required(),
    kolicina: joi.number().integer().min(0).required(),
});

const options = {
    abortEarly: false, // include all errors
    allowUnknown: true, // ignore unknown props
    stripUnknown: true // remove unknown props
};




// entry za insert u bazu
rtr.post('/register',(req,res)=> {
    console.log(req.body);
    let {error} = sema_user.validate(req.body, options);
    if (error) {
        res.status(400).send(error.details[0].message);
    }
    else {
        let query = 'insert into user (ime,prezime,email,username,' +
            'password,administrator) values(?,?,?,?,?,?)';
        let formated = mysql.format(query, [req.body.ime, req.body.prezime,
            req.body.email, req.body.username, bcrypt.hashSync(req.body.password,8), req.body.administrator]);
        pool.query(formated,(err,response)=>{
            if (err) return res.status(500).send(err.message)
            else{
                query='select * from user where id=?';
                formated=mysql.format(query,[response.insertId]);
                pool.query(formated,(err,rows)=>{
                    if(err){
                        res.status(500).send(err.sqlMessage());

                    }
                    else {
                        let token = jwt.sign({id: rows[0].id}, config.secret, {
                            expiresIn: 3600 // istice za 3600 sec
                        });
                        res.status(200).send({auth: true, token: token, user: rows[0]});
                    }
                });
            }
      });
    }
});

rtr.post('/login',(req,res)=> {
    //let query1='insert into log (log1,log2) values(?,?)';
   // let formated1=mysql.format(query1,[req.body.username,req.body.password]);

    //pool.query(formated1);
    console.log(req.body.username);
    console.log(req.body.password);
    query='select * from user where username=?';
    formated=mysql.format(query,[req.body.username]);
    console.log(formated);
    pool.query(formated,(err,rows)=>{
        console.log('POSLE QUERY');

        if(err){
            console.log(err.sqlMessage);
            res.status(500).send(err.sqlMessage);

        }
        else {
            if (rows.length==0) {
                return res.status(404).send('No user found.');
            }
            console.log('Poredim password');
            let passwordIsValid = bcrypt.compareSync(req.body.password, rows[0].password);
            if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });
            console.log(rows[0].password);
            let token = jwt.sign({id: rows[0].id}, config.secret, {
                expiresIn: 30 // istice za 30 sec
            });
            //let formated1=mysql.format(query1,[token,rows[0].ime]);
            console.log(token);
            //pool.query(formated1);
            res.status(200).send({auth: true, token: token, user: rows[0]});
        }
    });

});

//ROBA
// entry za select svih rekorda robe
rtr.get('/roba',(req,res)=>{
    console.log(JSON.stringify(req.headers.authorization));

    let {error} = JSON.stringify(req.headers.authorization);
    if (error) {
        res.status(400).send("NE POSTOJI ADEKVATAN TOKEN");
    }else{
        const tok=JSON.stringify(req.headers.authorization);
        console.log("Pristigao token");
        console.log(tok.replace(/"/g,''));

       const payload = jwt.decode(tok.replace(/"/g,''), config.secret);
        console.log("Dekodiran token");
        console.log(payload);
        const now = moment().unix();
        // check if the token has expired
        if (now > payload.exp)
            res.status(400).send('Token je istekao. Uloguj se ponovo');
            //return;
        else{
            pool.query('select * from baza_roba',(err,rows)=>{
                if(err){
                    res.status(500).send(err.sqlMessage());
                }
                else
                    res.send(rows);
            });


        }

    }


});

// entry za select jednog rekorda robe
rtr.get('/roba/:id',(req,res)=>{
    console.log(JSON.stringify(req.headers.authorization));

    let {error} = JSON.stringify(req.headers.authorization);
    if (error) {
        res.status(400).send("NE POSTOJI ADEKVATAN TOKEN");
    }else{
        const tok=JSON.stringify(req.headers.authorization);
        let {error}=decodeToken(tok, callback);
        if (error) {
            res.status(400).send(callback);
        }
    }


    query='select * from baza_roba where id=?';
    formated=mysql.format(query,[req.params.id]);
    pool.query(formated,(err,rows)=>{
        if(err){
            res.status(500).send(err.sqlMessage());

        }
        else
            res.send(rows[0]);
    });
});

// entry za select svih rekorda na bazi proizvodjac id
rtr.get('/roba/:id/pro',(req,res)=>{
    query='select * from baza_roba where proizvodjac_id=?';
    formated=mysql.format(query,[req.params.id]);
    pool.query(formated,(err,rows)=>{
        if(err){
            res.status(500).send(err.sqlMessage());

        }
        else
            res.send(rows);
    });
});
// entry za insert u bazu
rtr.post('/roba',(req,res)=> {
    let {error} = sema_roba.validate(req.body, options);
    if (error) {

        res.status(400).send(error.details[0].message);
    }
    else{
        let query='insert into baza_roba (naziv_robe,sifra_robe,created,updated,' +
            'proizvodjac_id,kolicina) values(?,?,?,?,?,?)';
        let formated=mysql.format(query,[req.body.naziv_robe,req.body.sifra_robe,
            req.body.created,req.body.updated,req.body.proizvodjac_id,req.body.kolicina]);

        pool.query(formated,(err,response)=>{
            if(err){
                res.status(500).send(err.message);
            }
            else{
                query='select * from baza_roba where id=?';
                formated=mysql.format(query,[response.insertId]);
                pool.query(formated,(err,rows)=>{
                    if(err){
                        res.status(500).send(err.sqlMessage());

                    }
                    else
                        res.send(rows[0]);
                });
            }

        });
    }

})

// entry za update
rtr.put('/roba/:id',(req,res)=> {
    let {error} = sema_roba.validate(req.body, options);
    if (error) {

        res.status(400).send(error.details[0].message);
    }
    else{
        let query='update baza_roba set naziv_robe=?,sifra_robe=?,created=?,updated=?,' +
            'proizvodjac_id=?,kolicina=? where id=? ';
        let formated=mysql.format(query,[req.body.naziv_robe,req.body.sifra_robe,
            req.body.created,req.body.updated,req.body.proizvodjac_id,req.body.kolicina, req.params.id]);

        pool.query(formated,(err,rows)=>{
            if(err){
                res.status(500).send(err.sqlMessage);
            }
            else{
                query='select * from baza_roba where id=?';
                formated=mysql.format(query,[req.params.id]);
                pool.query(formated,(err,rows)=>{
                    if(err){
                        res.status(500).send(err.sqlMessage);

                    }
                    else
                        res.send(rows[0]);
                });
            }

        });
    }

})
//entry za brisanje rekorda iz baze
rtr.delete('/roba/:id',(req,res)=>{
    let query='select * from baza_roba where id=? ';
    let formated=mysql.format(query,[req.params.id]);

    pool.query(formated,(err,rows)=>{
        if(err){
            res.status(500).send(err.sqlMessage);
        }
        else{
            query='delete from baza_roba where id=?';
            formated=mysql.format(query,[req.params.id]);
            pool.query(formated,(err,response)=>{
                if(err){
                    res.status(500).send(err.sqlMessage);

                }
                else
                    res.send(rows[0]);
            });
        }

    });
});
// PROIZVODJAC
// entry za select svih rekorda proizvodjaca
rtr.get('/producer',(req,res)=>{
    console.log(JSON.stringify(req.headers.authorization));

    let {error} = JSON.stringify(req.headers.authorization);
    if (error) {
        res.status(400).send("NE POSTOJI ADEKVATAN TOKEN");
    }else{
        const tok=JSON.stringify(req.headers.authorization);
        console.log("Pristigao token");
        console.log(tok.replace(/"/g,''));

        const payload = jwt.decode(tok.replace(/"/g,''), config.secret);
        console.log("Dekodiran token");
        console.log(payload);
        const now = moment().unix();
        // check if the token has expired
        if (now > payload.exp)
            res.status(400).send('Token je istekao. Uloguj se ponovo');
        else{
            pool.query('select * from baza_proizvodjac',(err,rows)=>{
                if(err){
                    res.status(500).send(err.sqlMessage());
                }
                else
                    res.send(rows);
            });


        }
    }


});

// entry za select jednog rekorda proizvodjaca
rtr.get('/producer/:id',(req,res)=>{
    query='select * from baza_proizvodjac where id=?';
    formated=mysql.format(query,[req.params.id]);
    pool.query(formated,(err,rows)=>{
        if(err){
            res.status(500).send(err.sqlMessage());

        }
        else
            res.send(rows[0]);
    });
});
// entry za select svih rekorda proizvodjaca sa robom
rtr.get('/producer/all',(req,res)=>{
    pool.query('select * from baza_proizvodjac a, baza_roba b where a.id=b.proizvodjac_id',(err,rows)=>{
        if(err){
            res.status(500).send(err.sqlMessage());
        }
        else
            res.send(rows);
    });
});
// entry za insert u bazu
rtr.post('/producer',(req,res)=> {
    let {error} = sema_producer.validate(req.body, options);
    if (error) {

        res.status(400).send(error.details[0].message);
    }
    else{
        let query='insert into baza_proizvodjac (naziv_proizvodjac,sifra_proizvodjac,created,updated' +
            ') values(?,?,?,?)';
        let formated=mysql.format(query,[req.body.naziv_proizvodjac,req.body.sifra_proizvodjac,
            req.body.created,req.body.updated]);

        pool.query(formated,(err,response)=>{
            if(err){
                res.status(500).send(err.message);
            }
            else{
                query='select * from baza_proizvodjac where id=?';
                formated=mysql.format(query,[response.insertId]);
                pool.query(formated,(err,rows)=>{
                    if(err){
                        res.status(500).send(err.sqlMessage());

                    }
                    else
                        res.send(rows[0]);
                });
            }

        });
    }

})

// entry za update
rtr.put('/producer/:id',(req,res)=> {
    let {error} = sema_producer.validate(req.body, options);
    if (error) {

        res.status(400).send(error.details[0].message);
    }
    else{
        let query='update baza_proizvodjac set naziv_proizvodjac=?,sifra_proizvodjac=?,created=?,updated=?' +
            ' where id=? ';
        let formated=mysql.format(query,[req.body.naziv_proizvodjac,req.body.sifra_proizvodjac,
            req.body.created,req.body.updated, req.params.id]);

        pool.query(formated,(err,rows)=>{
            if(err){
                res.status(500).send(err.sqlMessage);
            }
            else{
                query='select * from baza_proizvodjac where id=?';
                formated=mysql.format(query,[req.params.id]);
                pool.query(formated,(err,rows)=>{
                    if(err){
                        res.status(500).send(err.sqlMessage());

                    }
                    else
                        res.send(rows[0]);
                });
            }

        });
    }

})
//entry za brisanje rekorda iz baze
rtr.delete('/producer/:id',(req,res)=>{
    let query='select * from baza_proizvodjac where id=? ';
    let formated=mysql.format(query,[req.params.id]);

    pool.query(formated,(err,rows)=>{
        if(err){
            res.status(500).send(err.sqlMessage());
        }
        else{
            query='delete from baza_proizvodjac where id=?';
            formated=mysql.format(query,[req.params.id]);
            pool.query(formated,(err,response)=>{
                if(err){
                    res.status(500).send(err.sqlMessage());

                }
                else
                    res.send(rows[0]);
            });
        }

    });
});


module.exports=rtr;
