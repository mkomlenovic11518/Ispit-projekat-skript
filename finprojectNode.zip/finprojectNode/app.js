const express=require('express');
app= express();
const msg= require('./routes/messages');
const path=require('path');
const history=require('connect-history-api-fallback');
//const config = require('./config');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');


app.use('/api',msg);

app.use(function(req,res,next){
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET", "PUT", "POST", "DELETE", "OPTIONS");
    res.header("Access-Control-Allow-Headers", "*");
    next();
});

const staticDir=express.static(path.join(__dirname,'dist'));

app.use(staticDir);
app.use(history);
app.use(staticDir);

app.listen(8080,"127.0.0.1", () => console.log(`Server started, listening port:8080`));
