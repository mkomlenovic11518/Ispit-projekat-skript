from django.shortcuts import render, redirect, get_object_or_404,HttpResponse
import requests
import json
from django.contrib.auth.decorators import login_required, permission_required
from .models import Proizvodjac
from .models import Roba
from .models import User
from .forms import ProizvodjacForm
from .forms import RobaForm
from .forms import UserForm



def index(req):
   # if not req.user.is_authenticated:
    #    return render(req, 'index.html', {'page_title': 'Script projekat 2'})
  #  else:
        return redirect('demo_app:proizvodjaci')

def registracija(request):
    pass

#@login_required
def proizvodjaci(req):
    tmp = Proizvodjac.objects.all()
    return render(req, 'proizvodjaci.html', {'proizvodjaci': tmp})


#@login_required
def proizvodjac(req, id):
    tmp = get_object_or_404(Proizvodjac, id=id)
    return render(req, 'proizvodjac.html', {'proizvodjac': tmp, 'page_title': tmp.naziv_proizvodjac})


#@permission_required('demo_app.change_proizvodjac')
def edit(req, id):

    if req.method == 'POST':
        form = ProizvodjacForm(req.POST)

        if form.is_valid():
            a = Proizvodjac.objects.get(id=id)
            a.naziv_proizvodjac = form.cleaned_data['naziv_proizvodjac']
            a.sifra_proizvodjac = form.cleaned_data['sifra_proizvodjac']
            a.save()
            return redirect('demo_app:proizvodjaci')
        else:
            return render(req, 'edit.html', {'form': form, 'id': id})
    else:
        a = Proizvodjac.objects.get(id=id)
        form = ProizvodjacForm(instance=a)
        return render(req, 'edit.html', {'form': form, 'id': id})


#@permission_required('demo_app.add_proizvodjac')
def new(req):
    if req.method == 'POST':
        form = ProizvodjacForm(req.POST)

        if form.is_valid():
            a = Proizvodjac(naziv_proizvodjac=form.cleaned_data['naziv_proizvodjac'], sifra_proizvodjac=form.cleaned_data['sifra_proizvodjac'])
            a.save()
            return redirect('demo_app:proizvodjaci')
        else:
            return render(req, 'new.html', {'form': form})
    else:
        form = ProizvodjacForm()
        return render(req, 'new.html', {'form': form})

def users1(req):
    tmp = User.objects.all()
    return render(req, 'users1.html', {'users1': tmp})

def user11(req,id):
    tmp = get_object_or_404(User, id=id)
    return render(req, 'user11.html', {'user11': tmp, 'page_title': tmp.email})

def edit_user(req, id):
    if req.method == 'POST':
        form = UserForm(req.POST)

        if form.is_valid():
            a = User.objects.get(id=id)
            a.ime = form.cleaned_data['ime']
            a.prezime = form.cleaned_data['prezime']
            a.email = form.cleaned_data['email']
            a.username = form.cleaned_data['username']
            a.password = form.cleaned_data['password']
            a.administrator=form.cleaned_data['administrator']
            a.save()
            return redirect('demo_app:users1')
        else:
            return render(req, 'edit_user.html', {'form': form, 'id': id})

    else:
        a = User.objects.get(id=id)
        form = UserForm(instance=a)
        return render(req, 'edit_user.html', {'form': form, 'id': id})

def delete_user(req, id):
    tmp = get_object_or_404(User, id=id)
    tmp.delete()
    return render(req, 'users1.html')

#@login_required
def robe(req):
    tmp = Roba.objects.all()
    return render(req, 'robe.html', {'robe': tmp})

#@login_required
def robe_p(req,id):
    queryset = Roba.objects.filter(proizvodjac=id)
    return render(req, 'robe_p.html', {'robe_p': queryset})

#@login_required
def roba(req, id):
    tmp = get_object_or_404(Roba, id=id)
    return render(req, 'roba.html', {'roba': tmp, 'page_title': tmp.naziv_robe})

#@permission_required('demo_app.add_roba')
def new_roba(req):
    if req.method == 'POST':
        form = RobaForm(req.POST)

        if form.is_valid():
            a = Roba(naziv_robe=form.cleaned_data['naziv_robe'], sifra_robe=form.cleaned_data['sifra_robe'],kolicina=form.cleaned_data['kolicina'],proizvodjac=form.cleaned_data['proizvodjac'])
            a.save()
            return redirect('demo_app:robe')
        else:
            return render(req, 'new_roba.html', {'form': form})
    else:
        form = RobaForm()
        return render(req, 'new_roba.html', {'form': form})

#@permission_required('demo_app.change_roba')
def edit_roba(req, id):
    if req.method == 'POST':
        form = RobaForm(req.POST)

        if form.is_valid():
            a = Roba.objects.get(id=id)
            a.naziv_robe = form.cleaned_data['naziv_robe']
            a.sifra_robe = form.cleaned_data['sifra_robe']
            a.kolicina = form.cleaned_data['kolicina']
            a.proizvodjac=form.cleaned_data['proizvodjac']
            a.save()
            return redirect('demo_app:robe')
        else:
            return render(req, 'edit_roba.html', {'form': form, 'id': id})

    else:
        a = Roba.objects.get(id=id)
        form = RobaForm(instance=a)
        return render(req, 'edit_roba.html', {'form': form, 'id': id})

#@permission_required('demo_app.delete_roba')
def delete_roba(req, id):
    tmp = get_object_or_404(Roba, id=id)
    tmp.delete()
    return render(req, 'robe.html')

#@permission_required('demo_app.delete_proizvodjac')
def delete_proizvodjac(req, id):
    tmp = get_object_or_404(Proizvodjac, id=id)
    tmp.delete()
    return render(req, 'proizvodjaci.html')


def hello(request):
    r = requests.post('http://localhost:8084/user-service/api/user/login', json = {"email": "admin@gmail.com","password": "admin"})
    return HttpResponse(r.text)

def letovi(request):
    headers = {'Authorization': 'Bearer eyJhbGciOiJIUzUxMiJ9.eyJpZCI6MSwicm9sZSI6IlJPTEVfQURNSU4ifQ.dEuh0NrmaqBXOV5RrlIfUkTcKhXUJK0lf4gc7uanyuTmiTOdSkPEsMfB7CPt1pGOYz7JyVilV3cTs6u4IQtc7Q'}
    r = requests.get('http://localhost:8084/letovi-service/api/letovi',headers=headers)
    #r = requests.get('http://localhost:8084/letovi-service/api/letovi')
    dump=json.dumps(r.text)
    return HttpResponse(dump, content_type='application/json')

